const translations = {
  sv: {
    tagline: "Designad för en grön framtid.",
    welcome: "Välkommen",
    productsTitle: "Våra Produkter",
    about: "Om oss",
    aboutText: "RV-Form, ett innovativt plastföretag, använder sig av miljövänlig PLA-plast i sin 3D-printing, vilket ger hållbara, högkvalitativa produkter med precision och minimal miljöpåverkan.",
    contact: "Kontakt",
  },
  en: {
    tagline: "Designed for a green future.",
    welcome: "Welcome",
    productsTitle: "Our Products",
    about: "About us",
    aboutText: "RV-Form, an innovative plastics company, uses eco-friendly PLA in its 3D printing, delivering durable, high-quality products with precision and minimal environmental impact.",
    contact: "Contact",
  },
};

document.getElementById("lang-toggle").addEventListener("click", function () {
  const lang = this.textContent === "English" ? "en" : "sv";
  document.querySelectorAll("[data-key]").forEach((el) => {
    const key = el.getAttribute("data-key");
    el.textContent = translations[lang][key];
  });
  this.textContent = lang === "en" ? "Svenska" : "English";
});
